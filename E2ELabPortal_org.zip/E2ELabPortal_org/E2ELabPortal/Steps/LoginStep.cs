﻿using E2ELabPortal.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using E2ELabPortal.Drivers;

namespace E2ELabPortal.Steps
{
    [Binding]
   public class LoginStep:BasePage
    {


        private readonly LoginPage lPage;
        
        public LoginStep(Driver driver):base(driver)
        {

            lPage = new LoginPage(driver);
            
        }



        [Given(@"Browser is launched")]
        public void GivenBrowserIsLaunched()
        {
            GoTo();
        }


        [When(@"I click on Agree and Proceed button for cookies")]
        public void GivenIClickOnAgreeAndProceedButtonForCookies()
        {
            lPage.AcceptCookiesWindow();
            
        }


        [When(@"I click Close")]
        public void WhenIClickClose()
        {
            lPage.CloseCookieWindow();
        }





        [When(@"I enter username and password")]
        public void GivenIEnterUsernameAndPassword(Table table)
        {
            

            var credentials = table.CreateInstance<Credentials>();


            lPage.UserNameField.SendKeys(credentials.Username);
            lPage.PasswordField.SendKeys(credentials.Password);


        }

        [When(@"I Click Log on button")]
        public void GivenIClickLogOnButton()
        {
            lPage.LogonBtn.Click();
        }


        [Then(@"I verify Page title as Dashboard|LabPort")]
        public void ThenIVerifyPageTitleAsDashboardLabPort()
        {
            System.Threading.Thread.Sleep(TimeSpan.FromSeconds(5));
            Assert.True(lPage.PageTitle());
        }




    }
}
