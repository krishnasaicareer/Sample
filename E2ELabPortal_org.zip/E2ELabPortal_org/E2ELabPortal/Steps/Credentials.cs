﻿using System;
using System.Collections.Generic;
using System.Text;

namespace E2ELabPortal.Steps
{
    public class Credentials
    {

        public string Username { get; set; }

        public string Password { get; set; }

    }
}
