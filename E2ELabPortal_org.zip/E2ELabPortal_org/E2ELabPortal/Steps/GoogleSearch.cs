﻿using System;
using TechTalk.SpecFlow;
using E2ELabPortal.Drivers;
using E2ELabPortal.Pages;
using OpenQA.Selenium;

namespace E2ELabPortal.Steps
{
    [Binding]
    public class GoogleSearch : BasePage
    {
        private readonly GooglePage googlePage;
        

        public GoogleSearch(Driver driver):base(driver)
        {
            
            googlePage = new GooglePage(driver);
        }

        
        [Given(@"Browser is launched")]
        public void GivenBrowserIsLaunched()
        {
            GoTo();
        }
        
        [When(@"Entered the text in search bar")]
        public void WhenEnteredTheTextInSearchBar()
        {
            googlePage.ClickSearch();
            googlePage.EnterText();
        }
        
        [Then(@"The text is filled with the text")]
        public void ThenTheTextIsFilledWithTheText()
        {
            string text = googlePage.GetText();
            Console.WriteLine(text);
        }
    }
}
