﻿using OpenQA.Selenium;
using System;
using TechTalk.SpecRun;
using OpenQA.Selenium.Chrome;

namespace E2ELabPortal.Drivers
{
    public class BrowserDriver
    {

        private readonly ConfigurationDriver configurationDriver;
        private readonly TestRunContext testRunContext;
       
        public BrowserDriver(ConfigurationDriver configurationDriver, TestRunContext testRunContext)
        {
            this.configurationDriver = configurationDriver;
            this.testRunContext = testRunContext;
        }

        public IWebDriver GetBrowser(string browserType)
        {
            switch(browserType.ToUpper())
            {
                case "CHROME":
                    return GetChromeDriver();
                case "FIREFOX":
                    return GetFirefoxDriver();
                case "EDGE":
                    return GetEdgeBrowser();
                default: throw new NotSupportedException(string.Format("Unsupported browser {0} passed", browserType.ToUpper()));
            }
        }

        private IWebDriver GetEdgeBrowser()
        {
            throw new NotImplementedException();
        }

        private IWebDriver GetFirefoxDriver()
        {
            throw new NotImplementedException();
        }

        private IWebDriver GetChromeDriver()
        {
            ChromeOptions options = new ChromeOptions();
            //options.AddUserProfilePreference("profile.default_content_setting_values.cookies", 2);
            //options.AddUserProfilePreference("profile.block_third_party_cookies", true);
            options.AddArguments("--disable-extensions");
            options.AddExcludedArgument("enable-automation");
            options.AddAdditionalCapability("useAutomationExtension", false);
            options.AddUserProfilePreference("credentials_enable_service", false);
            options.AddUserProfilePreference("profile.password_manager_enabled", false);
            options.AddUserProfilePreference("profile.default_content_setting_values.clipboard", 1);
            options.AddArguments("--disable-popup-blocking");
            
            return new ChromeDriver(ChromeDriverService.CreateDefaultService(testRunContext.TestDirectory), options);
           


        }
        
    }
}