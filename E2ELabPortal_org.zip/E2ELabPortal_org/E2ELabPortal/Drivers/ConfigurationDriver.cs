﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;

namespace E2ELabPortal.Drivers
{
    public class ConfigurationDriver
    {
        private readonly Lazy<IConfiguration> lazyConfiguration;

        public ConfigurationDriver()
        {
            lazyConfiguration = new Lazy<IConfiguration>(GetConfiguration);
        }

        public IConfiguration Configuration => lazyConfiguration.Value;
        public string BaseUrl => Environment.GetEnvironmentVariable("__BaseUrl");

        private IConfiguration GetConfiguration()
        {
            var configurationBuilder = new ConfigurationBuilder();
            string directoryPath = Path.GetDirectoryName(typeof(ConfigurationDriver).Assembly.Location);
            configurationBuilder.AddJsonFile(Path.Combine(directoryPath, @"appsettings.json"));

            
            return configurationBuilder.Build();
        }
    }
}