﻿using System;
using System.Collections.Generic;
using System.Text;

namespace E2ELabPortal.Drivers
{
    public class BasePage
    {
        private readonly Driver driver;
        private readonly ConfigurationDriver configurationDriver;
        public BasePage(Driver driver)
        {
            this.driver = driver;
            configurationDriver = new ConfigurationDriver();
        }


        public void GoTo()
        {
            driver.CurrentDriver.Manage().Window.Maximize();
            driver.CurrentDriver.Url = configurationDriver.BaseUrl;
            System.Threading.Thread.Sleep(TimeSpan.FromSeconds(15));
            

        }
    }
}
