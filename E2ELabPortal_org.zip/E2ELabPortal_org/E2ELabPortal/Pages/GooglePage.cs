﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using E2ELabPortal.Drivers;

namespace E2ELabPortal.Pages
{
    public class GooglePage
    {
        private readonly Driver driver;
        
        
        public GooglePage(Driver driver)
        {
            this.driver = driver;
            
        }



        public IWebElement Search => driver.Wait.Until(d => d.FindElement(By.TagName("input[title='Search']")));
        


        public void ClickSearch()
        {

            Search.Click();
        }

        public void EnterText()
        {

            Search.SendKeys("Hi");
        }

        public string GetText()
        {

            return Search.Text;
        }

    }
}
