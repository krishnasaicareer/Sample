﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using E2ELabPortal.Drivers;


namespace E2ELabPortal.Pages
{
    public class LoginPage
    {
        private readonly Driver driver;
        public LoginPage(Driver driver)
        {
            this.driver = driver;
        }

        public IWebElement AgreeBtn => driver.Wait.Until(d=>d.FindElement(By.XPath("//a[@class ='call")));
        public IWebElement CloseBtn => driver.Wait.Until(d => d.FindElement(By.XPath("//a[@class ='close")));

        public IWebElement UserNameField => driver.Wait.Until(d => d.FindElement(By.Id("signInName")));

        public IWebElement PasswordField => driver.Wait.Until(d => d.FindElement(By.Id("password")));

        public IWebElement LogonBtn => driver.Wait.Until(d => d.FindElement(By.Id("next")));

        public bool PageTitle()
        {
            string title = driver.CurrentDriver.Title;

            if (title == "Dashboard|LabPort")
            {

                return true;

            }

            else return false;

        }

        public void AcceptCookiesWindow()
        {
            System.Threading.Thread.Sleep(10000);
            driver.CurrentDriver.SwitchTo().Frame(0);
            AgreeBtn.Click();
        }

        public void CloseCookieWindow()
        {
            CloseBtn.Click();
        }







    }
}
